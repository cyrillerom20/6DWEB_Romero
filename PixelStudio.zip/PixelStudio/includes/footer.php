    <footer>
      <div class="container">
        &copy; Pixel Studio <?= date('Y'); ?>
      </div>
    </footer>
    <script src="js/site.js"></script>
  </body>
</html>