<?php
declare(strict_types = 1);
require 'includes/database-connection.php';
require 'includes/functions.php';

// Get and sanitize search term
$search   = filter_input(INPUT_GET, 'search', FILTER_DEFAULT) ?? '';
$search   = trim($search);

$articles = [];
$searched = false;

if ($search !== '') {
    $searched = true;

    // PDO with emulate_prepares=false cannot reuse the same named placeholder.
    // Use four distinct param names instead (:s1–:s4).
    $sql = "SELECT a.id, a.title, a.summary, a.category_id, a.member_id,
            c.name AS category,
            CONCAT(m.forename, ' ', m.surname) AS author,
            i.file AS image_file,
            i.alt  AS image_alt
            FROM article AS a
            JOIN category AS c ON a.category_id = c.id
            JOIN member   AS m ON a.member_id   = m.id
            LEFT JOIN image AS i ON a.image_id  = i.id
            WHERE a.published = 1
              AND (a.title   LIKE :s1
               OR  a.summary LIKE :s2
               OR  a.content LIKE :s3
               OR  c.name    LIKE :s4)
            ORDER BY a.id DESC;";

    $term     = '%' . $search . '%';
    $articles = pdo($pdo, $sql, [
        's1' => $term,
        's2' => $term,
        's3' => $term,
        's4' => $term,
    ])->fetchAll();
}

$sql        = "SELECT id, name FROM category WHERE navigation = 1;";
$navigation = pdo($pdo, $sql)->fetchAll();

$section     = '';
$title       = $search !== '' ? 'Search: ' . $search : 'Search';
$description = 'Search the PixelStudio portfolio';
?>

<?php include 'includes/header.php'; ?>

<main class="container" id="content">

  <section class="header">
    <h1>Search</h1>
    <p>Find photography, branding, illustration and digital work.</p>
  </section>

  <section class="search-section">

    <form action="search.php" method="GET" class="form-search form-search-page" role="search">
      <label for="search-input">
        <span class="visually-hidden">Search</span>
      </label>
      <input
        type="text"
        id="search-input"
        name="search"
        class="form-control search-input"
        value="<?= html_escape($search) ?>"
        placeholder="e.g. portrait, branding, UI…"
        autocomplete="off"
        autofocus
      >
      <button type="submit" class="btn btn-primary search-btn">
        <span class="icon-search"></span> Search
      </button>
    </form>

    <?php if ($searched): ?>

      <?php if ($articles): ?>
        <p class="search-count">
          <?= count($articles) ?> result<?= count($articles) !== 1 ? 's' : '' ?> for
          <span class="search-term">&ldquo;<?= html_escape($search) ?>&rdquo;</span>
        </p>

        <section class="grid">
          <?php foreach ($articles as $article): ?>

          <article class="summary">

            <a href="article.php?id=<?= $article['id'] ?>">
              <img
                src="uploads/<?= html_escape($article['image_file'] ?? 'blank.png') ?>"
                alt="<?= html_escape($article['image_alt'] ?? '') ?>"
              >
              <h2><?= html_escape($article['title']) ?></h2>
              <p><?= html_escape($article['summary']) ?></p>
            </a>

            <p class="credit">
              Posted in
              <a href="category.php?id=<?= $article['category_id'] ?>">
                <?= html_escape($article['category']) ?>
              </a>
              by
              <a href="member.php?id=<?= $article['member_id'] ?>">
                <?= html_escape($article['author']) ?>
              </a>
            </p>

          </article>

          <?php endforeach; ?>
        </section>

      <?php else: ?>
        <p class="search-no-results">
          No results found for <span class="search-term">&ldquo;<?= html_escape($search) ?>&rdquo;</span>.
          Try a different keyword.
        </p>
      <?php endif; ?>

    <?php endif; ?>

  </section>

</main>

<?php include 'includes/footer.php'; ?>
