-- --------------------------------------------------------
-- DATABASE
-- --------------------------------------------------------

-- Database: pixelstudio_db
CREATE DATABASE pixelstudio_db;
USE pixelstudio_db;

-- --------------------------------------------------------
-- 1️⃣ CATEGORY TABLE
-- --------------------------------------------------------

CREATE TABLE category (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(24) NOT NULL,
  description VARCHAR(254) NOT NULL,
  navigation TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `category` VALUES
(1,'Branding','Logos, posters and print design',1),
(2,'Digital','UI/UX and web design',1),
(3,'Illustration','Digital artwork and characters',1),
(4,'Photography','Studio and outdoor photography',1);
-- --------------------------------------------------------
-- 2️⃣ MEMBER TABLE
-- --------------------------------------------------------

CREATE TABLE member (
  id INT(11) NOT NULL AUTO_INCREMENT,
  forename VARCHAR(254) NOT NULL,
  surname VARCHAR(254) NOT NULL,
  email VARCHAR(254) NOT NULL,
  password VARCHAR(255) NOT NULL,
  joined TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  picture VARCHAR(254) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `member` VALUES
(1,'Rov','Rivera','rov@pixelstudio.com','a2f3-92kd-x9v3-8ds1',NOW(), NUll),
(2,'James','Torres','jam@pixelstudio.com','9d2k-2sdf-93jd-0sdf',NOW(), NULL),
(3,'Garem','Cruz','garem@pixelstudio.com','3kd2-9sdf-92kd-1xza',NOW(), NULL);
-- --------------------------------------------------------
-- 3️⃣ IMAGE TABLE
-- --------------------------------------------------------

CREATE TABLE image (
  id INT(11) NOT NULL AUTO_INCREMENT,
  file VARCHAR(254) NOT NULL,
  alt VARCHAR(1000) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

IINSERT INTO `image` VALUES
(1,'city-night.jpg','City night photoshoot'),
(2,'brand-kit.jpg','Brand identity kit'),
(3,'fitness-ui.jpg','Fitness mobile UI'),
(4,'travel-landscape.jpg','Travel photography'),
(5,'mascot.jpg','Mascot illustration'),
(6,'coffee-shop.jpg','Coffee shop branding'),
(7,'startup-land.jpg','Startup landing page'),
(8,'nature.jpg','Nature photography'),
(9,'fantasy.jpg','Fantasy character illustration'),
(10,'music-event.jpg','Music event poster'),
(11,'portfolio-website.jpg','Creative portfolio website'),
(12,'concert.jpg','Concert flyer design'),
(13,'rebrand.jpg','Creative studio rebrand'),
(14,'product-package.jpg','Modern product packaging'),
(15,'street-photo.jpg','Street photography session'),
(16,'dashboard.jpg','Analytics dashboard UI'),
(17,'sci concept.jpg','Sci-fi concept illustration'),
(18,'product-landi.jpg','Product landing page'),
(19,'studio-potrait.jpg','Studio portrait photography'),
(20,'creative-business-card.jpg','Creative business card'),
(21,'chracter-concept.jpg','Game character concept art'),
(22,'marketing-camp.jpg','Marketing campaign visuals'),
(23,'city-travel.jpg','City travel photography'),
(24,'creative-catalog.jpg','Creative design catalog');
-- --------------------------------------------------------
-- 4️⃣ ARTICLE TABLE (AFTER OTHERS EXIST)
-- --------------------------------------------------------

CREATE TABLE article (
  id INT(11) NOT NULL AUTO_INCREMENT,
  title VARCHAR(80) NOT NULL,
  summary VARCHAR(254) NOT NULL,
  content TEXT NOT NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  category_id INT(11) NOT NULL,
  member_id INT(11) NOT NULL,
  image_id INT(11) DEFAULT NULL,
  published TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY title (title),
  KEY category_id (category_id),
  KEY member_id (member_id),
  KEY image_id (image_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `article` (`id`,`title`,`summary`,`content`,`created`,`category_id`,`member_id`,`image_id`,`published`) VALUES
(1,'City Night Photoshoot','Urban photography project','A cinematic night photoshoot capturing neon lights and street reflections.','2025-01-26 12:21:03',4,1,1,1),
(2,'Brand Identity Kit','Complete logo system','A modern branding package including logo, colors, and typography.','2025-01-28 19:44:03',1,1,2,1),
(3,'Fitness App UI','Mobile interface design','User interface design for a fitness tracking mobile application.','2025-02-02 09:45:52',2,3,3,1),
(4,'Mountain Landscape','Travel photography project','Landscape photography capturing mountains and sunrise scenery.','2025-02-12 11:05:35',4,3,4,1),
(5,'Fantasy Character Art','Digital illustration project','A fantasy warrior character created using digital illustration tools.','2025-02-26 15:31:16',3,2,5,1),
(6,'Coffee Shop Branding','Cafe brand identity','Brand design including menu, packaging and signage.','2025-03-02 21:02:47',1,2,6,1),
(7,'Startup Landing Page','Web design concept','A landing page design for a new startup company.','2025-03-06 10:16:22',2,1,7,1),
(8,'Forest Photography','Nature photo series','A photo series capturing forests and waterfalls.','2025-03-12 14:45:49',4,2,8,1),
(9,'Mascot Illustration','Brand mascot artwork','A fun illustrated mascot created for a technology brand.','2025-03-12 17:09:40',3,1,9,1),
(10,'Music Festival Poster','Event poster design','A vibrant poster designed for a summer music festival.','2025-03-16 14:14:40',1,1,10,1),
(11,'Portfolio Website','Creative portfolio','A modern website showcasing creative projects and design work.','2025-03-17 18:01:19',2,3,11,1),
(12,'Concert Flyer','Promotional design','A flyer designed for an upcoming live concert event.','2025-03-20 11:24:52',1,2,12,1),
(13,'Studio Rebrand','Creative agency refresh','A full rebrand for a creative media studio.','2026-03-21 08:44:01',1,2,13,1),
(14,'Product Packaging','Modern box packaging','Packaging design for a premium electronic product.','2026-03-27 13:15:20',1,1,14,1),
(15,'Street Photography','Urban photo session','Street photography capturing daily life in the city.','2026-04-03 20:36:08',4,2,15,1),
(16,'Dashboard UI','Admin interface design','A modern dashboard UI for analytics and management.','2026-04-06 11:21:44',2,1,16,1),
(17,'Sci-Fi Illustration','Digital concept art','A futuristic sci-fi city illustrated digitally.','2026-04-08 09:46:31',3,3,17,1),
(18,'Product Landing Page','Marketing web page','Landing page promoting a new technology product.','2026-04-08 18:05:19',2,1,18,1),
(19,'Studio Portrait','Professional portrait session','Studio portrait photography with professional lighting.','2026-04-11 11:52:02',4,2,19,1),
(20,'Creative Business Card','Brand identity design','A clean business card for a creative agency.','2026-04-15 10:04:39',1,2,20,1),
(21,'Character Concept Art','Game character illustration','Concept art created for a video game character.','2026-04-19 19:08:11',3,3,21,1),
(22,'Marketing Campaign','Advertising visuals','A digital marketing campaign design for social media.','2026-04-22 08:49:27',1,1,22,1),
(23,'City Travel Shoot','Urban travel photography','Travel photos captured across different city landmarks.','2026-04-25 13:51:19',4,3,23,1),
(24,'Creative Catalog','Design portfolio catalog','A printed catalog showcasing creative design works.','2026-04-25 20:11:42',1,1,24,1);

-- --------------------------------------------------------
-- 5️⃣ FOREIGN KEYS
-- --------------------------------------------------------

ALTER TABLE article
  ADD CONSTRAINT category_exists
    FOREIGN KEY (category_id) REFERENCES category(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT image_exists
    FOREIGN KEY (image_id) REFERENCES image(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT member_exists
    FOREIGN KEY (member_id) REFERENCES member(id)
    ON DELETE CASCADE ON UPDATE CASCADE;